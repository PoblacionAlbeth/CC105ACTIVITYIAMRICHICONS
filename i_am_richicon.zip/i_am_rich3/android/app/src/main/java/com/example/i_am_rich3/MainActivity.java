package com.example.i_am_rich3;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
